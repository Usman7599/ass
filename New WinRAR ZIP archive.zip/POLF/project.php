<!DOCTYPE html>
<html class="no-js" lang="en">
    <head>
        <!-- Meta tag -->
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
		<meta name="keywords" content="SITE KEYWORDS HERE" />
		<meta name="description" content="">
		<meta name='copyright' content='codeglim'>	
		
		<!-- Title Tag -->
		<title>Political &minus; Science</title>
		
		<!-- Favicon -->
		<link rel="icon" type="image/png" href="images/favicon.png">	
		
        <!-- Web Font -->
		<link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700,900" rel="stylesheet">
		
		<!-- Bootstrap CSS -->
        <link rel="stylesheet" href="css/bootstrap.min.css">
		
		<!-- Tromas CSS -->
		<link rel="stylesheet" href="css/theme-plugins.css">
        <link rel="stylesheet" href="style.css">
        <link rel="stylesheet" href="css/responsive.css">	
		
		<!-- Tromas Color -->
		<link rel="stylesheet" href="css/skin/skin1.css">
		<!--<link rel="stylesheet" href="css/skin/skin2.css">-->
		<!--<link rel="stylesheet" href="css/skin/skin3.css">-->
		<!--<link rel="stylesheet" href="css/skin/skin4.css">-->
		<!--<link rel="stylesheet" href="css/skin/skin5.css">-->
		<!--<link rel="stylesheet" href="css/skin/skin6.css">-->
		<!--<link rel="stylesheet" href="css/skin/skin7.css">-->
		<!--<link rel="stylesheet" href="css/skin/skin8.css">-->
		
		<!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
		<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
		<!--[if lt IE 9]>
		  <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
		  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
		<![endif]-->
		<link rel="stylesheet" href="#" id="tromas">	
    </head>
    <body id="bg" style="">
		<div id="layout" class="">
		
		
			<!-- Start Header -->
			<header id="header" class="header">
				<div class="container">
					<div class="row">
						<div class="col-md-3 col-sm-3 col-xs-12">
							<!-- Logo -->
							<div class="logo">
								<a href="index.html"><img src="images/logo.png" alt="logo" style="height: 250px;"></a>
							</div>
							<!--/ End Logo -->
							<div class="mobile-nav"></div>
						</div>
						<div class="col-md-9 col-sm-9 col-xs-12">
							<!-- Header Widget -->
							<div class="header-widget">
								<!-- Single Widget -->
								<div class="single-widget">
									<i class="fa fa-clock-o" id="f"></i>
									<h4>Openning Time</h4>
									<p>Mon-Sat: 8.00am-6.00pm</p>
								</div>
								<!--/ End Single Widget -->
								<!-- Single Widget -->
								<div class="single-widget">
									<i class="fa fa-envelope" id="f"></i>
									<h4>Email address</h4>
									<p><a href="mailto:info@yourwebsite">info@yourwebsite.com</a></p>
								</div>
								<!--/ End Single Widget -->
								<!-- Single Widget -->
								<div class="single-widget">
									<i class="fa fa-instagram" id="f"></i>
									<h4>Instagram</h4>
									<p><a href="https://www.instagram.com/napss_unilag/">napss_unilag</a></p>
								</div>
								<!--/ End Single Widget -->
							</div>
							<!--/ End Header Widget -->
						</div>
					</div>
				</div>
				<!-- Header Inner -->
				<div class="header-inner">
					<div class="container">
						<div class="row">
							<div class="col-md-12 col-sm-12 col-xs-12">
								<div class="nav-area">
									<!-- Main Menu -->
									<nav class="mainmenu">
										<div class="collapse navbar-collapse">	
											<ul class="nav navbar-nav">
												<li class=""><a href="#">Home</a></li>
												<li><a href="about-us.html">About Us</a></li>
												<li><a href="#">Event/News</a></li>					
												<li><a href="register.html">Registration</a></li>	
												
											</li>	
											
										</li>					
										<li><a href="studyguild.html">Study Guild</a></li>	
											
											<li><a href="contact.html">Contact</a></li>	

											</ul>
										</div>
									</nav>
									<!--/ End Main Menu -->
									<!-- Social -->
									<ul class="social">
										<li><a href="#"><i class="fa fa-instagram"></i></a></li>
										<li><a href="#"><i class="fa fa-facebook"></i></a></li>
										<li class=""><a href="#"><i class="fa fa-twitter"></i></a></li>
									</ul>
									<!--/ End Social -->
								</div>
							</div>
						</div>
					</div>
				</div>
				<!--/ End Header Inner -->
			</header>
			<!--/ End Header -->
		
			<!-- Start Breadcrumbs -->
			<section class="breadcrumbs">
				<div class="container">
					<div class="row">
						<div class="col-md-12 col-sm-12 col-xs-12">
							<h2>Awesome Projects</h2>
							<ul class="bread-list">
								<li><a href="index.html">Home<i class="fa fa-angle-right"></i></a></li>
								<li class="active"><a href="projects-masonry.html">Projects Masonry</a></li>
							</ul>
						</div>
					</div>
				</div>
			</section>
			<!--/ End Breadcrumbs -->
		
			<!-- Start Project -->
			<section id="projects" class="projects section">
				<div class="container">
					<div class="row">
						<div class="col-md-12 col-sm-12 col-xs-12">
							<div class="section-title">
								<h1>Our Works</h1>
								<p>Contry to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece Distinctio tenetur, dolores aperiam, quasi perferendis nemo mollitia</p>
							</div>
						</div>
					</div>
					<div class="row">
						<div class="col-md-12 col-sm-12 col-xs-12">
							<!-- project Nav -->
							<div class="project-nav">
								<ul class="cbp-l-filters-work" id="project-menu">
									<li data-filter="*" class="cbp-filter-item active">All<div class="cbp-filter-counter"></div></li>  
									<li data-filter=".webdesign" class="cbp-filter-item">Design<div class="cbp-filter-counter"></div></li>
									<li data-filter=".development" class="cbp-filter-item">Development<div class="cbp-filter-counter"></div></li>
									<li data-filter=".branding" class="cbp-filter-item">Branding<div class="cbp-filter-counter"></div></li>
									<li data-filter=".package" class="cbp-filter-item">Package<div class="cbp-filter-counter"></div></li>
									<li data-filter=".video" class="cbp-filter-item">Video<div class="cbp-filter-counter"></div></li>
								</ul>  		
							</div>
							<!--/ End project Nav -->
						</div>
					</div>					
					<div class="row">
						<div class="col-md-12 col-sm-12 col-xs-12">
							<div id="project-item" class="cbp">
								<div class="cbp-item  webdesign development video branding package">
									<!-- Single Project -->
									<div class="project-single">
										<div class="project-inner">
											<div class="project-head">
												<img src="images/project/1.jpg" alt=""/>
											</div>
											<div class="project-bottom">
												<h4><a href="#">Powerfull Theme</a><span class="category">Development</span></h4>
											</div>
											<div class="button">
												<a href="https://www.youtube.com/watch?v=E-2ocmhF6TA" class="btn video-play cbp-lightbox"><i class="fa fa-play"></i></a>
												<a href="project-single.html" class="btn"><i class="fa fa-link"></i></a>
											</div>
										</div>
									</div> 
									<!--/ End Single Project -->
								</div>
								<div class="cbp-item  webdesign branding package">
									<!-- Single Project -->
									<div class="project-single">
										<div class="project-inner">
											<div class="project-head">
												<img src="images/project/2.jpg" alt=""/>
											</div>
											<div class="project-bottom">
												<h4><a href="#">Crazy Design</a><span class="category">Branding</span></h4>
											</div>
											<div class="button">
												<a data-fancybox="portfolio" href="images/project/2.jpg" class="btn"><i class="fa fa-photo"></i></a>
												<a href="project-single.html" class="btn"><i class="fa fa-link"></i></a>
											</div>
										</div>
									</div>
									<!--/ End Single Project -->
								</div>
								<div class="cbp-item  webdesign development video">
									<!-- Single Project -->
									<div class="project-single">
										<div class="project-inner">
											<div class="project-head">
												<img src="images/project/msonry1.jpg" alt=""/>
											</div>
											<div class="project-bottom">
												<h4><a href="#">Bootstrap Framework</a><span class="category">Development</span></h4>
											</div>
											<div class="button">
												<a href="https://www.youtube.com/watch?v=E-2ocmhF6TA" class="btn video-play cbp-lightbox"><i class="fa fa-play"></i></a>
												<a href="project-single.html" class="btn"><i class="fa fa-link"></i></a>
											</div>
										</div>
									</div>
									<!--/ End Single Project -->
								</div>
								<div class="cbp-item branding development">
									<!-- Single Project -->
									<div class="project-single">
										<div class="project-inner">
											<div class="project-head">
												<img src="images/project/msonry2.jpg" alt=""/>
											</div>
											<div class="project-bottom">
												<h4><a href="#">Fully Responsive</a><span class="category">Branding</span></h4>
											</div>
											<div class="button">
												<a data-fancybox="portfolio" href="images/project/msonry2.jpg" class="btn"><i class="fa fa-photo"></i></a>
												<a href="project-single.html" class="btn"><i class="fa fa-link"></i></a>
											</div>
										</div>
									</div>
									<!--/ End Single Project -->
								</div>
								<div class="cbp-item  webdesign development video">
									<!-- Single Project -->
									<div class="project-single">
										<div class="project-inner">
											<div class="project-head">
												<img src="images/project/5.jpg" alt=""/>
											</div>
											<div class="project-bottom">
												<h4><a href="#">Easy To Use</a><span class="category">Development</span></h4>
											</div>
											<div class="button">
												<a href="https://www.youtube.com/watch?v=E-2ocmhF6TA" class="btn video-play cbp-lightbox"><i class="fa fa-play"></i></a>
												<a href="project-single.html" class="btn"><i class="fa fa-link"></i></a>
											</div>
										</div>
									</div>
									<!--/ End Single Project -->
								</div>
								<div class="cbp-item  webdesign development branding">
									<!-- Single Project -->
									<div class="project-single">
										<div class="project-inner">
											<div class="project-head">
												<img src="images/project/6.jpg" alt=""/>
											</div>
											<div class="project-bottom">
												<h4><a href="#">Modern Design</a><span class="category">Printing</span></h4>
											</div>
											<div class="button">
												<a data-fancybox="portfolio" href="images/project/6.jpg" class="btn"><i class="fa fa-photo"></i></a>
												<a href="project-single.html" class="btn"><i class="fa fa-link"></i></a>
											</div>
										</div>
									</div>
									<!--/ End Single Project -->
								</div>
								<div class="cbp-item  webdesign development branding">
									<!-- Single Project -->
									<div class="project-single">
										<div class="project-inner">
											<div class="project-head">
												<img src="images/project/msonry3.jpg" alt=""/>
											</div>
											<div class="project-bottom">
												<h4><a href="#">Modern Design</a><span class="category">Printing</span></h4>
											</div>
											<div class="button">
												<a data-fancybox="portfolio" href="images/project/msonry3.jpg" class="btn"><i class="fa fa-photo"></i></a>
												<a href="project-single.html" class="btn"><i class="fa fa-link"></i></a>
											</div>
										</div>
									</div>
									<!--/ End Single Project -->
								</div>
								<div class="cbp-item  webdesign development branding">
									<!-- Single Project -->
									<div class="project-single">
										<div class="project-inner">
											<div class="project-head">
												<img src="images/project/1.jpg" alt=""/>
											</div>
											<div class="project-bottom">
												<h4><a href="#">Modern Design</a><span class="category">Printing</span></h4>
											</div>
											<div class="button">
												<a data-fancybox="portfolio" href="images/project/1.jpg" class="btn"><i class="fa fa-photo"></i></a>
												<a href="project-single.html" class="btn"><i class="fa fa-link"></i></a>
											</div>
										</div>
									</div>
									<!--/ End Single Project -->
								</div>
								<div class="cbp-item  webdesign development branding">
									<!-- Single Project -->
									<div class="project-single">
										<div class="project-inner">
											<div class="project-head">
												<img src="images/project/1.jpg" alt=""/>
											</div>
											<div class="project-bottom">
												<h4><a href="#">Modern Design</a><span class="category">Printing</span></h4>
											</div>
											<div class="button">
												<a data-fancybox="portfolio" href="images/project/1.jpg" class="btn"><i class="fa fa-photo"></i></a>
												<a href="project-single.html" class="btn"><i class="fa fa-link"></i></a>
											</div>
										</div>
									</div>
									<!--/ End Single Project -->
								</div>
							</div>
						</div>
					</div>
				</div>
			</section>
			<!--/ End Project -->
		
			<!-- Start Footer -->
			<footer id="footer" class="footer">
				<div class="footer-top">
					<div class="container">
						<div class="row">
							<div class="col-md-3 col-sm-6 col-xs-12">
								<!-- Address Widget -->
								<div class="single-widget address">
									<ul class="list">
										<li><i class="fa fa-instagram"></i>Instagram: +123 456-7890 </li>
										<li><i class="fa fa-envelope"></i>Email:<a href="mailto:info@youremail.com">Info@youremail.com</a></li>
										<li><i class="fa fa-map-o"></i>Address: University of Lagos, Akoka, Yaba, Lagos.</li>
									</ul>		
									<ul class="social">
										<li><a href="#"><i class="fa fa-facebook"></i></a></li>
										<li><a href="#"><i class="fa fa-twitter"></i></a></li>
									</ul>
								</div>
								<!--/ End Address Widget -->
							</div>	
							<div class="col-md-3 col-sm-6 col-xs-12">
								<!-- Links Widget -->
								<div class="single-widget links">
									<h2>Quick Links</h2>
									<ul class="list">
										<li><a href="about-us.html"><i class="fa fa-angle-right"></i>About Us</a></li>
										<li><a href="services.html"><i class="fa fa-angle-right"></i>Our Latest Event</a></li>
										<li><a href="#"><i class="fa fa-angle-right"></i>Help Desk</a></li>
										<li><a href="contact.html"><i class="fa fa-angle-right"></i>Contact With Us</a></li>
									</ul>
								</div>
								<!--/ End Links Widget -->
							</div>
							<div class="col-md-3 col-sm-6 col-xs-12">
							</div>
							<div class="col-md-3 col-sm-6 col-xs-12">
								<!-- Gallery Widget -->
								<div class="single-widget photo-gallery">
									<h2>Photo Gallery</h2>
									<ul class="list">
										<li><a href="images/gallery-1.jpg" data-fancybox="photo"><img src="images/gallery-1.jpg" alt="#"></a></li>
										<li><a href="images/gallery-2.jpg" data-fancybox="photo"><img src="images/gallery-2.jpg" alt="#"></a></li>
										<li><a href="images/gallery-3.jpg" data-fancybox="photo"><img src="images/gallery-3.jpg" alt="#"></a></li>
										<li><a href="images/gallery-4.jpg" data-fancybox="photo"><img src="images/gallery-4.jpg" alt="#"></a></li>
										<li><a href="images/gallery-5.jpg" data-fancybox="photo"><img src="images/gallery-5.jpg" alt="#"></a></li>
										<li><a href="images/gallery-6.jpg" data-fancybox="photo"><img src="images/gallery-6.jpg" alt="#"></a></li>
										<li><a href="images/gallery-7.jpg" data-fancybox="photo"><img src="images/gallery-7.jpg" alt="#"></a></li>
										<li><a href="images/gallery-8.jpg" data-fancybox="photo"><img src="images/gallery-8.jpg" alt="#"></a></li>
										<li><a href="images/gallery-9.jpg" data-fancybox="photo"><img src="images/gallery-9.jpg" alt="#"></a></li>
									</ul>
								</div>
								<!--/ End Gallery Widget -->
							</div>
						</div>
					</div>
				</div>
				<div class="footer-bottom">
					<div class="container">
						<div class="row">
							<div class="col-md-12 col-sm-12 col-xs-12">
								<!-- copyright -->
								<div class="copyright">
									<p>&copy; 2021 All Right Reserved.</p>
								</div>
								<!--/ End Copyright -->
							</div>
						</div>
					</div>
				</div>
			</footer>
			<!--/ End footer -->
			
			<!-- Jquery -->
			<script src="js/jquery.min.js" type="text/javascript"></script>
			<!-- Bootstrap JS -->
			<script src="js/bootstrap.min.js" type="text/javascript"></script>
			<!-- Modernizer JS -->
			<script src="js/modernizr.min.js" type="text/javascript"></script>
			<!-- Tromas JS -->
			<script src="js/tromas.js" type="text/javascript"></script>
			<!-- Tromas Plugins -->
			<script src="js/theme-plugins.js" type="text/javascript"></script>
			<!-- Google Map JS -->
			<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyDnhgNBg6jrSuqhTeKKEFDWI0_5fZLx0vM" type="text/javascript"></script>	
			<script src="js/gmap.min.js"  type="text/javascript" ></script>
			<!-- Main JS -->
			<script src="js/main.js" type="text/javascript"></script>
		</div>
    </body>
</html>