<!DOCTYPE html>
<html>

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Political &minus; Science</title>

    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="font-awesome/css/font-awesome.css" rel="stylesheet">
    <link href="css/plugins/iCheck/custom.css" rel="stylesheet">
    <link href="css/animate.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <link rel="shortcut icon" href="images/logo.png" type="image/x-icon">

</head>

<body class="gray-bg">

    <div class="middle-box text-center loginscreen   animated fadeInDown">
        <div>
            <div>

               <div>
                   <div>
                    <button style="margin-left: -1190px;"><a href="index.php" style="outline: none; color: black;">Home</a></button>
                   </div>
                   <img src="images/logo.png" alt="" class="logo" style="height: 150px;">
               </div>

            </div>
            <p>Create account to see it in action.</p>
            <form class="m-t" role="form" method="POST">
                  
                  <?php
                     include ('conn.php');
                     error_reporting(E_ALL);
                     if (isset($_REQUEST['submit'])){
                     $fullname = $_REQUEST['fullname'];
                     $matric = $_REQUEST ['matric'];
                     $phone = $_REQUEST ['phone'];
                     $dob = $_REQUEST ['dob'];
                     $password = $_REQUEST ['password'];
                    
                     
                          
                   $check=mysqli_query($conn, "SELECT * FROM pol WHERE matric='$matric'");
                   $checkrows=mysqli_num_rows($check);
                   if($checkrows>0){
                   echo "<script>alert('Matric number already exist in database')</script>";
                  }
                  else{
                    $sql = "INSERT INTO pol(fullname, matric, phone, dob, password) VALUES('$fullname','$matric','$phone','$dob','$password')";
    
                    mysqli_query($conn, $sql) or die(mysqli_error($conn));
                    $num= mysqli_insert_id($conn);
                    if(mysqli_affected_rows($conn)!=1){
   
                   $message="Error inserting into record";
                    }

                      echo"<script>alert('$fullname data succcessfully submitted')
                      location.href='login.php'</script>";

                          }
                        }

                     ?>

                <div class="form-group">
                    <input type="text" class="form-control" placeholder="Full- Name" required="" name="fullname">
                </div>
                <div class="form-group">
                    <input type="text" class="form-control" placeholder="Matric. No" required="" name="matric">
                </div>
                <div class="form-group">
                    <input type="phone" class="form-control" placeholder="Phone" required="" name="phone">
                </div>

                <div class="form-group">
                    <input type="date" class="form-control" placeholder="" required="" name="dob">
                </div>

                <div class="form-group">
                    <input type="password" class="form-control" placeholder="Password" required="" name="password">
                </div>
               
                <button type="submit" class="btn btn-primary block full-width m-b" style="background-color: black; border-color: cornsilk; width: 150px;" name="submit">Register</button>

                <p class="text-muted text-center" style="margin-top: 20px;"><small>Already have an account?</small></p>
                <a class="btn btn-sm btn-white btn-block" href="login.php" style="margin-top: 10px;">Login</a>
            </form>
            <div class="copyright" style="margin-top: 95px;">
                <p>&copy; 2021 All Right Reserved.</p>
            </div>
        </div>
    </div>

    <!-- Mainly scripts -->
    <script src="js/jquery-2.1.1.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <!-- iCheck -->
    <script src="js/plugins/iCheck/icheck.min.js"></script>
    <script>
        $(document).ready(function(){
            $('.i-checks').iCheck({
                checkboxClass: 'icheckbox_square-green',
                radioClass: 'iradio_square-green',
            });
        });
    </script>
</body>

</html>
