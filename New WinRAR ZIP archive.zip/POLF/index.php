<!DOCTYPE html>
<html class="no-js" lang="en">
    <head>
        <!-- Meta tag -->
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
		<meta name="keywords" content="SITE KEYWORDS HERE" />
		<meta name="description" content="">
		<meta name='copyright' content='codeglim'>	
		
		<!-- Title Tag -->
        <title>Political &minus; Science</title>
		
		<!-- Favicon -->
		<link rel="icon" type="image/png" href="images/logo.png">	
		
        <!-- Web Font -->
		<link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700,900" rel="stylesheet">
		
		<!-- Bootstrap CSS -->
        <link rel="stylesheet" href="css/bootstrap.min.css">
		
		<!-- Tromas CSS -->
		<link rel="stylesheet" href="css/theme-plugins.css">
        <link rel="stylesheet" href="style.css">
        <link rel="stylesheet" href="css/responsive.css">	
		
		<!-- Tromas Color -->
		<link rel="stylesheet" href="css/skin/skin1.css">
		<!--<link rel="stylesheet" href="css/skin/skin2.css">-->
		<!--<link rel="stylesheet" href="css/skin/skin3.css">-->
		<!--<link rel="stylesheet" href="css/skin/skin4.css">-->
		<!--<link rel="stylesheet" href="css/skin/skin5.css">-->
		<!--<link rel="stylesheet" href="css/skin/skin6.css">-->
		<!--<link rel="stylesheet" href="css/skin/skin7.css">-->
		<!--<link rel="stylesheet" href="css/skin/skin8.css">-->
		
		<!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
		<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
		<!--[if lt IE 9]>
		  <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
		  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
		<![endif]-->
		<link rel="stylesheet" href="#" id="tromas">	
    </head>
    <body id="bg" style="">
		<div id="layout" class="">
		
		
			<!-- Start Header -->
			<header id="header" class="header">
				<div class="container">
					<div class="row">
						<div class="col-md-3 col-sm-3 col-xs-12">
							<!-- Logo -->
							<div class="logo">
								<a href="index.php"><img src="images/logo.png" alt="logo" style="height: 250px;"></a>
							</div>
							<!--/ End Logo -->
							<div class="mobile-nav"></div>
						</div>
						<div class="col-md-9 col-sm-9 col-xs-12">
							<!-- Header Widget -->
							<div class="header-widget">
								<!-- Single Widget -->
								<div class="single-widget">
									<i class="fa fa-clock-o" id="f"></i>
									<h4>Openning Time</h4>
									<p>Mon-Sat: 8.00am-6.00pm</p>
								</div>
								<!--/ End Single Widget -->
								<!-- Single Widget -->
								
								<!--/ End Single Widget -->
								<!-- Single Widget -->
								<div class="single-widget">
									<i class="fa fa-instagram" id="f"></i>
									<h4>Instagram</h4>
									<p><a href="https://www.instagram.com/napss_unilag/">napss_unilag</a></p>
								</div>
								<!--/ End Single Widget -->
							</div>
							<!--/ End Header Widget -->
						</div>
					</div>
				</div>
				<!-- Header Inner -->
				<div class="header-inner">
					<div class="container">
						<div class="row">
							<div class="col-md-12 col-sm-12 col-xs-12">
								<div class="nav-area">
									<!-- Main Menu -->
									<nav class="mainmenu">
										<div class="collapse navbar-collapse">	
											<ul class="nav navbar-nav">
												<li class=""><a href="index.php">Home</a></li>
												<li><a href="about-us.php">About Us</a></li>
												<li><a href="index.php">Event/News</a></li>					
												<li><a href="register.php">Registration</a></li>	
												
											</li>	
											
										</li>					
								
											
											<li><a href="contact.php">Contact</a></li>	

											</ul>
										</div>
									</nav>
									<!--/ End Main Menu -->
									<!-- Social -->
									<ul class="social">
										<li><a href="#"><i class="fa fa-instagram"></i></a></li>
										<li><a href="#"><i class="fa fa-facebook"></i></a></li>
										<li class=""><a href="#"><i class="fa fa-twitter"></i></a></li>
									</ul>
									<!--/ End Social -->
								</div>
							</div>
						</div>
					</div>
				</div>
				<!--/ End Header Inner -->
			</header>
			<!--/ End Header -->
		
			<!-- Start Hero Area -->
			<section class="hero-area">
				<div class="slider-one">
					<!-- Single Slider --> 
					<div class="single-slider" style="background-image:url('images/slider/slide1.jpg');" style="border-radius: 50px;">
						<div class="container">
							<div class="row">
								<div class="col-md-7 col-sm-12 col-xs-12">
									<!-- Slider Text -->
									<div class="slide-text">
										<h1><span class="short" style="color: black;">Welcome to</span>Department of Political science.</h1>
										<p style="color: black;">Welcome to the Homopoliticus Page, Contrary to the belief that Humans are Political Animal,We invoke the virtue of skeptiticism, Why can't we be Social?</p>
										<div class="slide-btn">	
												<div class="waves-block">
													<div class="waves wave-1"></div>
													<div class="waves wave-2"></div>
													<div class="waves wave-3"></div>
												</div>
											</a>
										</div>
									</div>
									<!--/ End SLider Text -->
								</div>
							</div>
						</div>
					</div>
					<!--/ End Single Slider -->
					<!-- Single Slider --> 
					<div class="single-slider" style="background-image:url('images/slider/slide2.jpg')">
						<div class="container">
							<div class="row">
								<div class="col-md-7 col-md-offset-5 col-sm-12 col-xs-12">
									<!-- Slider Text -->
									<div class="slide-text right">
										<h1><span class="short" style="color: black;">Homo</span>Politicus</h1>
										<p style="color: black">Everyone of you is important to us and we are here to listen to that exhilirating opinion of yours and also make your day a bright one deep down your heart where the sun couldn't reach.</p>
										<div class="slide-btn">	
											<a href="contact.php" class="btn primary">Contact Us</a>
										</div>
									</div>
									<!--/ End SLider Text -->
								</div>
							</div>
						</div>
					</div>
					<!--/ End Single Slider -->
					<!-- Single Slider --> 
					<div class="single-slider" style="background-image:url('images/slider/slider-bg3.jpg')">
						<div class="container">
							<div class="row">
								<div class="col-md-7 col-sm-12 col-xs-12">
									<!-- Slider Text -->
									<div class="slide-text">
										<h1><span class="short" style="color: black;">Department of </span>Political science.</h1>
										<p style="color: black;"></p>
										<div class="slide-btn">	
										</div>
									</div>
									<!--/ End SLider Text -->
								</div>
							</div>
						</div>
					</div>
					<!--/ End Single Slider -->
				</div>
			</section>
			<!--/ End Hero Area -->
			
			<!-- Start Features -->
			
			<!--/ End Features -->
			
			<!-- Start Services -->
			<section id="services" class="services section">
				<div class="container">
					<div class="row">
						<div class="col-md-12 col-sm-12 col-xs-12">
							<div>
								<p><h1 style="margin-left: 40%; margin-bottom: 40px;">News/Event</h1></p>
								<img src="images/news1.png" alt="" style="margin-left: 10px; height: 250px;">
								<p><b>THE NAPSS UNITY MATCH RE EMERGE</b> <br>
								To all loving Homopoliticus, <br>
							This is to inform you that the NAPSS UNITY MATCH that was cancelled a week ago has been <br>scheduled to hold on the 16th of December 2021 <br> <br> <br><b>The Venue:</b> Staff School <br><b>Date:</b>Thursday, 16th 2021 <br><b>Time:</b>4pm-6pm <br> GREATEST NAPSSITE! DO GRACE THIS MEMORABLE EVENT WITH THE MAJESTIC PRESENCE. <br> <br><b>NAPSS Executive-Elect.</b></p>



							<img src="images\slider1.jpg" alt="" style="margin-left: 10px; height: 250px;">
								<p>
								<b>Fresher's Orientation programme</b> 
								
								</p>
								
								 <br><b>Date:</b>Monday, 16th 2021 <br><b>Time:</b>10am-2pm <br> GREATEST NAPSSITE! DO GRACE THIS MEMORABLE EVENT WITH THE MAJESTIC PRESENCE. <br> <br><b>NAPSS Executive-Elect.</b></p>


							<img src="images/sport2.png" alt="" style="margin-left: 10px; height: 250px;">
							</div>
							<div class="section-title">
								<h1>Our Objective</h1>
								
							</div>
						</div>
					</div>
					<div class="row">
						<!-- Single Service -->
						<div class="col-md-4 col-sm-6 col-xs-12">
							<div class="single-services">
								<div class="icon"><i class="fa fa-edit" style="margin-top: -15px;"></i></div>
								<div class="icon two"><i class="fa fa-edit"  style="margin-top: -15px;"></i></div>
								<h2><a href="service-single.html">Education Consulting</a></h2>
							
							</div>
						</div>
						<!--/ End Single Service -->
						<!-- Single Service -->
						<div class="col-md-4 col-sm-6 col-xs-12">
							<div class="single-services">
								<div class="icon"><i class="fa fa-lightbulb-o" style="margin-top: -15px;"></i></div>
								<div class="icon two"><i class="fa fa-lightbulb-o" style="margin-top: -15px;"></i></div>
								<h2><a href="#">Creative Writings</a></h2>
								
							</div>
						</div>
						<!--/ End Single Service -->
						<!-- Single Service -->
						<div class="col-md-4 col-sm-6 col-xs-12">
							<div class="single-services">
								<div class="icon"><i class="fa fa-money" style="margin-top: -15px;"></i></div>
								<div class="icon two"><i class="fa fa-money" style="margin-top: -15px;"></i></div>
								<h2><a href="service-single.html">News/Event</a></h2>
							
							</div>
						</div>
						<!--/ End Single Service -->
						<!-- Single Service -->
						<div class="col-md-4 col-sm-6 col-xs-12">
							<div class="single-services">
								<div class="icon"><i class="fa fa-clock-o" style="margin-top: -15px;"></i></div>
								<div class="icon two"><i class="fa fa-clock-o"style="margin-top: -15px;"></i></div>
								<h2><a href="service-single.html">Thursday Lines</a></h2>
							
							</div>
						</div>
						<!--/ End Single Service -->
						<!-- Single Service -->
						<div class="col-md-4 col-sm-6 col-xs-12">
							<div class="single-services">
								<div class="icon"><i class="fa fa-globe" style="margin-top: -15px;"></i></div>
								<div class="icon two"><i class="fa fa-globe" style="margin-top: -15px;"></i></div>
								<h2><a href="service-single.html">Face of the Week</a></h2>
								
							</div>
						</div>
						<!--/ End Single Service -->
						<!-- Single Service -->
						<div class="col-md-4 col-sm-6 col-xs-12">
							<div class="single-services">
								<div class="icon"><i class="fa fa-magic" style="margin-top: -15px;"></i></div>
								<div class="icon two"><i class="fa fa-magic" style="margin-top: -15px;"></i></div>
								<h2><a href="service-single.html">Trusted Support</a></h2>
								
							</div>
						</div>
						<!--/ End Single Service -->
					</div>
				</div>
			</section>
			<!--/ End Services -->
			
			<!-- Why Choose Us -->
		
			<!--/ End Why Choose Us -->
			
			<!-- Start Projects -->
			
			<!--/ End Projects -->
		
			<!-- Start Team -->
			<section id="team" class="team section">
				<div class="container">
					<div class="row">
						<div class="col-md-12 col-sm-12 col-xs-12">
							<div class="section-title">
								<h1>Meet The Executive(2021/2022)</h1>
							</div>
						</div>
					</div>
			</section>
			<!--/ End Team -->

			<!-- Start Blogs -->
			<section id="blog-main" class="blog-main section">
					<div class="row">
						<div class="blog-main">
							<div class="col-md-12 col-sm-12 col-xs-12">
								<div class="blog-slider">
									<!-- Single Slider -->
									<div class="single-blog single-slider">
										<div class="blog-post">
											<div class="blog-head">
												<img src="images/IMG-20211209-WA0004.jpg" alt="#" style="height: 200px; width: 200px;">
												<a class="link" href="#"><i class="fa fa-paper-plane"></i></a>
											</div>
											<div class="blog-info">
												<h1><a href="#" style="color: black;">President</a></h1>
												<div class="meta">
													
												</div>
												<p><h4 style="font-family: calibri; font-size: small; margin-left: 20px;">Madojutimi Ayomide</h4></p>
											</div>
										</div>				
									</div>
									<!--/ End Single Slider -->	
									<!-- Single Slider -->
									<div class="single-blog single-slider">
										<div class="blog-post">
											<div class="blog-head">
												<img src="images/lovella.png" alt="#" style="height: 200px; width: 200px;">
												<a class="link" href="#"><i class="fa fa-paper-plane"></i></a>
											</div>
											<div class="blog-info">
												<h1><a href="#" style="color: black;">Vice President</a></h1>
												<div class="meta">
													
												</div>
												<p><h4 style="font-family: calibri; font-size: small; margin-left: 20px;">Bankole Ayomikun Mercy</h4></p>
											</div>
										</div>				
									</div>
									<!--/ End Single Slider -->	
									<!-- Single Slider -->
									<div class="single-blog single-slider">
										<div class="blog-post">
											<div class="blog-head">
												<img src="images/adekunle.png" alt="#"  style="height: 200px; width: 200px;">
												<a class="link" href="#"><i class="fa fa-paper-plane"></i></a>
											</div>
											<div class="blog-info">
												<h1><a href="#" style="color: black;">General Secretary</a></h1>
												<div class="meta">
													
												</div>
												<p><h4 style="font-family: calibri; font-size: small; margin-left: 20px;">Adekunle Adejare</h4></p>
											</div>
										</div>				
									</div>
									<!--/ End Single Slider -->	
									<!-- Single Slider -->
									<div class="single-blog single-slider">
										<div class="blog-post">
											<div class="blog-head">
												<img src="images/Yemisi.jpg" alt="#" style="height: 200px; width: 200px;">
												<a class="link" href="#"><i class="fa fa-paper-plane"></i></a>
											</div>
											<div class="blog-info">
												<h1><a href="#" style="color: black;">Asst.General Secretary</a></h1>
												<div class="meta">
												
												</div>
												<p>Yemisi</p>
											</div>
										</div>				
									</div>
									<!--/ End Single Slider -->	
									<!-- Single Slider -->
									<div class="single-blog single-slider">
										<div class="blog-post">
											<div class="blog-head">
												<img src="images/tomiwa.png" alt="#" style="height: 200px; width: 200px;">
												<a class="link" href="#"><i class="fa fa-paper-plane"></i></a>
											</div>
											<div class="blog-info">
												<h1><a href="#" style="color: black;">Treasurer</a></h1>
												<div class="meta">
												
												</div>
												<p><h4 style="font-family: calibri; font-size: small; margin-left: 20px;">Oyedepo Oluwatomiwa</h4></p>
											</div>
										</div>				
									</div>
									<!--/ End Single Slider -->	
									<!-- Single Slider -->
									<div class="single-blog single-slider">
										<div class="blog-post">
											<div class="blog-head">
												<img src="images/mazil.png" alt="#" style="height: 200px; width: 200px;">
												<a class="link" href="#"><i class="fa fa-paper-plane"></i></a>
											</div>
											<div class="blog-info">
												<h1><a href="#" style="color: black;">Financial Secretary</a></h1>
												<div class="meta">
												
												</div>
												<p><h4 style="font-family: calibri; font-size: small; margin-left: 20px;">Onuh Emmanuel Oche</h4></p>
											</div>
										</div>				
									</div>


									<div class="single-blog single-slider">
										<div class="blog-post">
											<div class="blog-head">
												<img src="#" alt="#" style="height: 200px; width: 200px;">
												<a class="link" href="#"><i class="fa fa-paper-plane"></i></a>
											</div>
											<div class="blog-info">
												<h1><a href="#" style="color: black;">Asst.Financial Secretary</a></h1>
												<div class="meta">
												
												</div>
												<p></p>
											</div>
										</div>				
									</div>

									<div class="single-blog single-slider">
										<div class="blog-post">
											<div class="blog-head">
												<img src="#" alt="#" style="height: 200px; width: 200px;">
												<a class="link" href="#"><i class="fa fa-paper-plane"></i></a>
											</div>
											<div class="blog-info">
												<h1><a href="#" style="color: black;">Welfare Secretary</a></h1>
												<div class="meta">
												
												</div>
												<p><h4 style="font-family: calibri; font-size: small; margin-left: 20px;">Oluleye Odunayo Esther</h4></p>
											</div>
										</div>				
									</div>

									<div class="single-blog single-slider">
										<div class="blog-post">
											<div class="blog-head">
												<img src="images/funmi.png" alt="#" style="height: 200px; width: 200px;">
												<a class="link" href="#"><i class="fa fa-paper-plane"></i></a>
											</div>
											<div class="blog-info">
												<h1><a href="#" style="color: black;">Asst.Welfare Secretary</a></h1>
												<div class="meta">
												
												</div>
												<p><h4 style="font-family: calibri; font-size: small; margin-left: 20px;">Eniobamo Funmilayo Martha</h4></p>
											</div>
										</div>				
									</div>

									<div class="single-blog single-slider">
										<div class="blog-post">
											<div class="blog-head">
												<img src="images/korede.JPG" alt="#" style="height: 200px; width: 200px;">
												<a class="link" href="#"><i class="fa fa-paper-plane"></i></a>
											</div>
											<div class="blog-info">
												<h1><a href="#" style="color: black;">Sport Secretary</a></h1>
												<div class="meta">
												
												</div>
												<p><h4 style="font-family: calibri; font-size: small; margin-left: 20px;">Dada Korede</h4></p>
											</div>
										</div>				
									</div>


									<div class="single-blog single-slider">
										<div class="blog-post">
											<div class="blog-head">
												<img src="images/omolade.png" alt="#" style="height: 200px; width: 200px;">
												<a class="link" href="#"><i class="fa fa-paper-plane"></i></a>
											</div>
											<div class="blog-info">
												<h1><a href="#" style="color: black;">Asst.Sport Secretary</a></h1>
												<div class="meta">
												
												</div>
												<p>Faniyi Omolade Abdul-Rasaq</p>
											</div>
										</div>				
									</div>


									<div class="single-blog single-slider">
										<div class="blog-post">
											<div class="blog-head">
												<img src="images/boluwatife.png" alt="#" style="height: 200px; width: 200px;">
												<a class="link" href="#"><i class="fa fa-paper-plane"></i></a>
											</div>
											<div class="blog-info">
												<h1><a href="#" style="color: black;">Social Secretary</a></h1>
												<div class="meta">
												
												</div>
												<p>Adeyinminu Boluwatife Ayomide</p>
											</div>
										</div>				
									</div>


									<div class="single-blog single-slider">
										<div class="blog-post">
											<div class="blog-head">
												<img src="images/ejiro.png" alt="#" style="height: 200px; width: 200px;">
												<a class="link" href="#"><i class="fa fa-paper-plane"></i></a>
											</div>
											<div class="blog-info">
												<h1><a href="#" style="color: black;">Asst.Social Secretary</a></h1>
												<div class="meta">
												
												</div>
												<p>Edafe Ejiro</p>
											</div>
										</div>				
									</div>





									<div class="single-blog single-slider">
										<div class="blog-post">
											<div class="blog-head">
												<img src="#" alt="#" style="height: 200px; width: 200px;">
												<a class="link" href="#"><i class="fa fa-paper-plane"></i></a>
											</div>
											<div class="blog-info">
												<h1><a href="#" style="color: black;"></a>Public Relations Officer</h1>
												<div class="meta">
												
												</div>
												<p><h4 style="font-family: calibri; font-size: small; margin-left: 20px;">Ogunyooye Micheal Adeola</h4></p>
											</div>
										</div>				
									</div>

									<div class="single-blog single-slider">
										<div class="blog-post">
											<div class="blog-head">
												<img src="images/rasheed.jpg" alt="#" style="height: 200px; width: 200px;">
												<a class="link" href="#"><i class="fa fa-paper-plane"></i></a>
											</div>
											<div class="blog-info">
												<h1><a href="#" style="color: black;"></a>Asst.Public Relations Officer</h1>
												<div class="meta">
												
												</div>
												<p><h4 style="font-family: calibri; font-size: small; margin-left: 20px;"> Abolade Rasheed</h4></p>
											</div>
										</div>				
									</div>
									<!--/ End Single Slider -->									
								</div>
							</div>
						</div>						
					</div>
				</div>
			</section>
			<!--/ End Blog -->	
			
			<!-- Start Call-To-Action -->
			<section class="call-to-action" id="section">
				<div class="container">
					<div class="row">
						<div class="col-md-12 col-sm-12 col-xs-12">
							<div class="call-to-main">
								<a href="contact.php" class="btn"><i class="fa fa-send"></i>Contact Us</a>
							</div>
						</div>
					</div>
				</div>
			</section>
			<!--/ End Call-To-Action -->
			
			<!-- Start Footer -->
			<footer id="footer" class="footer">
				<div class="footer-top">
					<div class="container">
						<div class="row">
							<div class="col-md-3 col-sm-6 col-xs-12">
								<!-- Address Widget -->
								<div class="single-widget address">
									<ul class="list">
										<li><i class="fa fa-instagram"></i>Instagram:<a href="https://www.instagram.com/napss_unilag/">napss_unilag</a></li>
										<li><i class="fa fa-map-o"></i>Address: University of Lagos, Akoka, Yaba, Lagos.</li>
									</ul>		
									<ul class="social">
										<li><a href="#"><i class="fa fa-facebook"></i></a></li>
										<li><a href="#"><i class="fa fa-twitter"></i></a></li>
									</ul>
								</div>
								<!--/ End Address Widget -->
							</div>	
							<div class="col-md-3 col-sm-6 col-xs-12">
								<!-- Links Widget -->
								<div class="single-widget links" id="link">
									<h2>Quick Links</h2>
									<ul class="list">
										<li><a href="about-us.html"><i class="fa fa-angle-right"></i>About Us</a></li>
										<li><a href="services.html"><i class="fa fa-angle-right"></i>Our Latest Event</a></li>
										<li><a href="#"><i class="fa fa-angle-right"></i>Help Desk</a></li>
										<li><a href="contact.html"><i class="fa fa-angle-right"></i>Contact With Us</a></li>
									</ul>
								</div>
								<!--/ End Links Widget -->
							</div>
							<div class="col-md-3 col-sm-6 col-xs-12">
							</div>
							<div class="col-md-3 col-sm-6 col-xs-12">
								<!-- Gallery Widget -->
								
								<!--/ End Gallery Widget -->
							</div>
						</div>
					</div>
				</div>
				<div class="footer-bottom">
					<div class="container">
						<div class="row">
							<div class="col-md-12 col-sm-12 col-xs-12">
								<!-- copyright -->
								<div class="copyright">
									<p>&copy; 2021 All Right Reserved.</p>
								</div>
								<!--/ End Copyright -->
							</div>
						</div>
					</div>
				</div>
			</footer>
			<!--/ End footer -->
			
			<!-- Jquery -->
			<script src="js/jquery.min.js" type="text/javascript"></script>
			<!-- Bootstrap JS -->
			<script src="js/bootstrap.min.js" type="text/javascript"></script>
			<!-- Modernizer JS -->
			<script src="js/modernizr.min.js" type="text/javascript"></script>
			<!-- Tromas JS -->
			<script src="js/tromas.js" type="text/javascript"></script>
			<!-- Tromas Plugins -->
			<script src="js/theme-plugins.js" type="text/javascript"></script>
			<!-- Google Map JS -->
			<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyDnhgNBg6jrSuqhTeKKEFDWI0_5fZLx0vM" type="text/javascript"></script>	
			<script src="js/gmap.min.js"  type="text/javascript" ></script>
			<!-- Main JS -->
			<script src="js/main.js" type="text/javascript"></script>
		</div>
    </body>
</html>