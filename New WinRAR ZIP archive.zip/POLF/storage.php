<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<section id="contact-us" class="contact-us section">
				<div class="container">
					<div class="row">
						<div class="col-md-12 col-sm-12 col-xs-12">
							
						</div>
					</div>
					<div class="row">
						<!-- Contact Form -->
				         <div class="col-md-8 col-sm-6 col-xs-12">
							<form class="form" method="post" action="mail/mail.php">
								<div class="row">
									<div>
										<div>You are welcome to this platform. <br> The following materials can be downloaded to back up your studies.</div>
										<div style="margin-top: 20px;">100lv Materials</div>
										<ul>

								<li><a href="document/Corruption in Nigeria 2.pdf" style="background-color: black; color: white;padding: 6px;">Corruption in Nigeria</a></li>
							     <li><a href="document/Agr.Oth.Lib.17 (1).pdf" style="margin-top: 10px; background-color: black; color: white; padding: 6px;">Economics</a></li>
							</ul>
									</div>
									<div>
										<div style="margin-top: 20px;">200lv Materials</div>
										<ul>

											<li><a href="document/Corruption in Nigeria 2.pdf" style="background-color: black; color: white;padding: 6px;">Corruption in Nigeria</a></li>
											 <li><a href="document/Agr.Oth.Lib.17 (1).pdf" style="margin-top: 10px; background-color: black; color: white; padding: 6px;">Economics</a></li>
										</ul>	
									</div>
									<div>
										<div style="margin-top: 20px;">300lv Materials</div>
										<ul>

											<li><a href="document/Corruption in Nigeria 2.pdf" style="background-color: black; color: white;padding: 6px;">Corruption in Nigeria</a></li>
											 <li><a href="document/Agr.Oth.Lib.17 (1).pdf" style="margin-top: 10px; background-color: black; color: white; padding: 6px;">Economics</a></li>
										</ul>	
									</div>
									<div>
										<div style="margin-top: 20px;">400lv Materials</div>
										<ul>

											<li><a href="document/Corruption in Nigeria 2.pdf" style="background-color: black; color: white;padding: 6px;">Corruption in Nigeria</a></li>
											 <li><a href="document/Agr.Oth.Lib.17 (1).pdf" style="margin-top: 10px; background-color: black; color: white; padding: 6px;">Economics</a></li>
										</ul>	
									</div>
									<div class="col-md-12">
										
									</div>
								</div>
							</form>
						</div> 
						<!--/ End Contact Form -->
						<!-- Contact Address -->
						
						<!--/ End Contact Address -->
					</div>
				</div>
			</section> 
</body>
</html>