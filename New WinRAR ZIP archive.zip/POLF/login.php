<?php
require('conn.php');
session_start();
// If form submitted, insert values into the database.
if (isset($_REQUEST['matric'])){
    
    $matricreg = stripslashes($_REQUEST['matric']); // removes backslashes
    $matricreg = mysqli_real_escape_string($conn,$matricreg); //escapes special characters in a string
    $passwordreg = stripslashes($_REQUEST['password']);
    $passwordreg = mysqli_real_escape_string($conn,$passwordreg);
    
    
    
//Checking is user existing in the database or not
    $query = "SELECT * FROM `pol` WHERE matric='$matricreg' AND password=('$passwordreg')";
    $result = mysqli_query($conn,$query) or die(mysql_error());
    $rows = mysqli_num_rows($result);
    if($rows==1){
        $_SESSION['matric'] = $matricreg;
        echo '<script type="text/javascript"> window.open("studyguild.php","_self");</script>'; // Redirect user to index.php
        }{
     echo "<script>alert('Invalid Email & Password ')
             location.href='login.php'</script>";
}
 }


?>






<!DOCTYPE html>
<html>

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Political &minus; Science</title>

    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="font-awesome/css/font-awesome.css" rel="stylesheet">

    <link href="css/animate.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <link rel="shortcut icon" href="images/logo.png" type="image/x-icon">

</head>

<body class="gray-bg">

    <div class="middle-box text-center loginscreen animated fadeInDown">
        <div>
            <div>

                <div>
                    <img src="images/logo.png" alt="" class="logo" style="height: 150px;">
                </div>
 

            </div>
            <p>Login in. To see it in action.</p>
            <form class="m-t"  method="POST">
                <div class="form-group">
                    <input type="number" class="form-control" placeholder="Matric.No" required="" name="matric">
                </div>
                <div class="form-group">
                    <input type="password" class="form-control" placeholder="Password" required="" name="password">
                </div>
                <button type="submit" class="btn btn-primary block full-width m-b" style="background-color: black; width: 150px; margin-top: 20px;">Login</button>
                <p class="text-muted text-center" style="margin-top: 20px;"><small>Do not have an account?</small></p>
                <a class="btn btn-sm btn-white btn-block" href="register.php" style="margin-top: 20px;">Create an account</a>
            </form>
            <div class="copyright">
                <p style="margin-top: 240px;">&copy; 2021 All Right Reserved.</p>
            </div>
        </div>
    </div>

    <!-- Mainly scripts -->
    <script src="js/jquery-2.1.1.js"></script>
    <script src="js/bootstrap.min.js"></script>

</body>

</html>
