<?php
   $conn= new mysqli("localhost", "pol_user", "ay@2021", "pol");
   if(mysqli_connect_errno()){
       printf("connect failed: %s\n", mysqli_connect_error());
       exit();
   }


?>